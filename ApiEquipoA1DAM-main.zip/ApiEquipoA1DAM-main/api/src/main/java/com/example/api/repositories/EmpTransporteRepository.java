package com.example.api.repositories;

import com.example.api.models.EmpTransporte;
import org.springframework.data.repository.ListCrudRepository;

public interface EmpTransporteRepository extends ListCrudRepository<EmpTransporte, Integer> {
}