package com.example.api.repositories;

import com.example.api.models.ProfResponsable;
import org.springframework.data.repository.ListCrudRepository;

public interface ProfResponsableRepository extends ListCrudRepository<ProfResponsable, Integer> {
}